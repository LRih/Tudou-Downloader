<?php

error_reporting(0);

const KEY_1 = "becaf9be";
const KEY_2 = "bf7e5f01";


// not all parameters set
if (!isset($_GET["key"]) || !isset($_GET["url"]) || !isset($_GET["quality"]))
    navigate_home();

// authentication
if ($_GET["key"] !== "authentication")
    navigate_home();


$url = $_GET["url"];
$quality = $_GET["quality"];

echo "<strong>url: ".$url."</strong><br>";
echo "<strong>quality: ".$quality."</strong><br>";

try
{
    $service10 = get_service($url, 10);
    $service12 = get_service($url, 12);
    print_base_video($service10, $service12, $quality);
}
catch (Exception $e)
{
}


function get_service($url, $ct)
{
    preg_match("/http:\/\/v\.youku\.com\/v_show\/id_(.+?)\.html.*/", $url, $m);

    $id = $m[1];
    $service_url = "http://play.youku.com/play/get.json?ct=".$ct."&vid=".$id;

    return get_json($service_url);
}

function print_base_video($service10, $service12, $quality)
{
    $stream = get_stream($service10, $quality);
    $security = $service12->data->security;

    // decrypt encryption
    $decrypt = base64_decode($security->encrypt_string);
    $decrypt = rc4(KEY_1, $decrypt);

    $split_decrypt = explode("_", $decrypt);
    $sid = $split_decrypt[0];
    $token = $split_decrypt[1];

    echo "<strong>stream: ".$stream->stream_type."</strong><br>";

    for ($i = 0; $i < count($stream->segs); $i++)
    {
        $seg = $stream->segs[$i];

        $container = get_container($stream->stream_type);
        $ep = generate_ep($i, $stream->stream_fileid, $sid, $token);

        // get link
        $query = array(
            "ctype" => 12,
            "ev" => 1,
            "K" => $seg->key,
            "ep" => $ep[1],
            "oip" => $security->ip,
            "token" => $token,
            "yxon" => 1,
        );

        $url = "http://k.youku.com/player/getFlvPath/sid/".$sid."_00/st/".$container."/fileid/".$ep[0]."?".http_build_query($query);
        $vid_url = get_json($url)[0]->server;

        echo "<div>".$vid_url."</div>";
    }
}

function get_stream($service, $quality)
{
    $streams = $service->data->stream;
    $types = get_types($quality);

    // find highest quality up to requested
    foreach ($types as $type)
        foreach ($streams as $stream)
            if ($stream->stream_type === $type)
                return $stream;

    return null;
}


function get_types($quality)
{
    $types = array(
        array("types" => array("mp4hd3", "hd3"), "container" => "flv"),
        array("types" => array("mp4hd2", "hd2"), "container" => "flv"),
        array("types" => array("mp4hd", "mp4"), "container" => "mp4"),
        array("types" => array("flvhd", "flv"), "container" => "flv")
    );

    $result = array();

    for ($i = $quality; $i < count($types); $i++)
        $result = array_merge($result, $types[$i]["types"]);

    return $result;
}

function get_container($type)
{
   switch ($type)
   {
       case "mp4hd3":
       case "hd3": return "flv";
       case "mp4hd2":
       case "hd2": return "flv";
       case "mp4hd":
       case "mp4": return "mp4";
       case "flvhd": return "flv";
       case "flv": return "flv";
       case "3gphd": return "3gp";
   }

   throw new Exception("Invalid type: " + type);
}


function generate_ep($index, $streamfileid, $sid, $token)
{
    $hex = strtoupper(str_pad(dechex($index), 2, "0", STR_PAD_LEFT));
    $streamfileid = substr($streamfileid, 0, 8).$hex.substr($streamfileid, 10);

    $ep = $sid."_".$streamfileid."_".$token;
    $ep = base64_encode(rc4(KEY_2, $ep));

    return [$streamfileid, $ep];
}

function rc4($key, $str)
{
	$s = array();
	for ($i = 0; $i < 256; $i++)
		$s[$i] = $i;
    
	$j = 0;
	for ($i = 0; $i < 256; $i++)
    {
		$j = ($j + $s[$i] + ord($key[$i % strlen($key)])) % 256;
		$x = $s[$i];
		$s[$i] = $s[$j];
		$s[$j] = $x;
	}
    
	$i = 0;
	$j = 0;
	$res = '';
	for ($y = 0; $y < strlen($str); $y++)
    {
		$i = ($i + 1) % 256;
		$j = ($j + $s[$i]) % 256;
		$x = $s[$i];
		$s[$i] = $s[$j];
		$s[$j] = $x;
		$res .= $str[$y] ^ chr($s[($s[$i] + $s[$j]) % 256]);
	}
    
	return $res;
}


function get_json($url)
{
    $options = array(
        "http" => array(
            "method" => "GET",
            "header" => "Cookie: __ysuid=".time()."\r\n".
                        "Referer: http://static.youku.com/"
        )
    );

    $context = stream_context_create($options);
    $src = file_get_contents($url, false, $context);

    return json_decode($src);
}


function jprint($json)
{
    $json = json_encode($json, JSON_PRETTY_PRINT);
    echo "<pre>".$json."</pre>";
}

function navigate_home()
{
    header('Location: ../../');
    die();
}


function test()
{
    $encrypt = "PwXXRwkYJbPe2ffJ8+JxVdbx7xNs1w7MWxs=";
    $ip = "3541779832";
    $streamfileid = "03008014005804B5A0AE20055DF531D0D110B0-95AF-47ED-8560-037F7EC7BFED";
    $key = "da04d849bc167003261f5a9a";

    $decrypt = base64_decode($encrypt);
    $decrypt = rc4($GLOBALS["key1"], $decrypt);
    echo "decrypt: ".$decrypt."<br>";

    $split_decrypt = explode("_", $decrypt);
    $sid = $split_decrypt[0];
    $token = $split_decrypt[1];

    $ep = generate_ep(0, $streamfileid, $decrypt);

    // get link
    $query = array(
        "ctype" => 12,
        "ev" => 1,
        "K" => $key,
        "ep" => $ep[1],
        "oip" => $ip,
        "token" => $token,
        "yxon" => 1,
    );

    $file_url = "http://k.youku.com/player/getFlvPath/sid/".$sid."_00/st/flv/fileid/".$ep[0]."?".http_build_query($query);

    echo "url: <a href='".$file_url."'>".$file_url."</a><br>";
}

?>